</div>
<!--end::Content-->

<!--end::Main-->
<script>var hostUrl = "assets/";</script>
		<!--begin::Javascript-->
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="<?php print(ROOT_PATH) ?>assets/plugins/global/plugins.bundle.js"></script>
		<script src="<?php print(ROOT_PATH) ?>assets/js/scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--end::Page Vendors Javascript-->
		<!--begin::Page Custom Javascript(used by this page dashboard)-->
		<script src="<?php print(ROOT_PATH) ?>assets/js/custom/widgets.js"></script>
		<script src="<?php print(ROOT_PATH) ?>assets/js/custom/apps/chat/chat.js"></script>
		<script src="<?php print(ROOT_PATH) ?>assets/js/custom/modals/create-app.js"></script>
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>