<?php

$path = '/KRATOS/';
define('ROOT_PATH', '/KRATOS/');

?>
