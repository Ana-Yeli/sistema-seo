# KRATOS



## FRONT-END SISTEMA SEO
```
Esta página web de monitoreo electoral busca proporcionar a los usuarios una herramienta completa y precisa para seguir y comprender el proceso electoral en tiempo real, incluyendo la posibilidad de hacer proyecciones preliminares basadas en los datos disponibles. Esto contribuye a la transparencia y la participación en el proceso democrático.
```

```
cd existing_repo
git remote add origin https://gitlab.com/sistema-eo/kratos.git
git branch -M main
git push -uf origin main
```

## Tecnologias

- HTML5
- CSS3
- METRONIC 
- JAVASCRIPT 