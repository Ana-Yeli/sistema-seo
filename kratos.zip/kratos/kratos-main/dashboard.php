<?php 
    include('bar.php');
?>


	<!--begin::Post-->
	<div class="post d-flex flex-column-fluid mb-5 mb-xl-10 " id="kt_post">
		
						<!--begin::Toolbar-->
						<div class="toolbar" id="kt_toolbar">
							<!--begin::Container-->
							<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
								<!--begin::Page title-->
								<div data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}" class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
									<!--begin::Title-->
									<h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1">INICIO</h1>
									<!--end::Title-->
									<!--begin::Separator-->
									<span class="h-20px border-gray-200 border-start mx-4"></span>
									<!--end::Separator-->
									
								</div>
								<!--end::Page title-->
								
								<!--begin::Actions-->
								<div class="d-flex align-items-center py-1">
									<!--begin::Wrapper-->
									<div class="me-4">
										<!--begin::Menu-->
										<a href="#" class="btn btn-sm btn-flex btn-light-danger btn-active-danger fw-bolder" data-bs-toggle="modal" data-bs-target="#kt_modal_create_app">INCIDENCIAS</a>
									
									</div>
									<!--end::Wrapper-->
									<!--begin::Button-->
									
									<a href="#" class="btn btn-sm btn-light-danger" data-bs-toggle="modal" data-bs-target="#kt_modal_create_api_key" id="kt_toolbar_primary_button">ASIGNAR PROSPECTO</a>
									<!--end::Button-->
								</div>
								<!--end::Actions-->
								
							
							</div>
							<!--end::Container-->
						</div>
						<!--end::Toolbar-->
						
					</div>
					<!--end::Content-->
							
						</div>
						<!--end::Toolbar-->
		<!--begin::Container-->
		<div id="kt_content_container mb-5 mb-xl-10" class="container-xxl">
			<!--begin::Navbar-->
			<div class="card mb-5 mb-xl-10">
				<div class="card-body pt-9 pb-0">
					<!--begin::Details-->
					<div class="d-flex flex-wrap flex-sm-nowrap mb-3">
						<!--begin: Pic-->
						<div class="me-7 mb-4">
							<div class="symbol symbol-100px symbol-lg-160px symbol-fixed position-relative">
								<img src="<?php print(ROOT_PATH) ?>assets/media/avatars/blank.png" alt="image" />
								<div class="position-absolute translate-middle bottom-0 start-100 mb-6 bg-success rounded-circle border border-4 border-white h-20px w-20px">									
								</div>
							</div>
						</div>
						<!--end::Pic-->
						<!--begin::Info-->
						<div class="flex-grow-1">
							<!--begin::Title-->
							<div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
								<!--begin::User-->
								<div class="d-flex flex-column">
									<!--begin::Name-->
									<div class="d-flex align-items-center mb-2">
										<a class="text-gray-900 text-hover-primary fs-2 fw-bolder me-1">Teocuitatlán de Corona</a>
									</div>
									<!--end::Name-->
									<!--begin::Info-->
									<div class="d-flex flex-wrap fw-bold fs-6 mb-4 pe-2">
										<label class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
											<span class="svg-icon svg-icon-4 me-1">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<path opacity="0.3" d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM12 7C10.3 7 9 8.3 9 10C9 11.7 10.3 13 12 13C13.7 13 15 11.7 15 10C15 8.3 13.7 7 12 7Z" fill="black" />
													<path d="M12 22C14.6 22 17 21 18.7 19.4C17.9 16.9 15.2 15 12 15C8.8 15 6.09999 16.9 5.29999 19.4C6.99999 21 9.4 22 12 22Z" fill="black" />
												</svg>
											</span>
										Coordinador municipal:</label>
										<label class="fw-bolder fs-6 text-gray-800">JOSE JUAN LEOPOLDO MURILLO ORTEGA</label>
									</div>
									<!--end::Info-->
								</div>
								<!--end::User-->
							</div>
							<!--end::Title-->
							<!--begin::Stats-->
							<div class="d-flex flex-wrap flex-stack">
								<!--begin::Wrapper-->
								<div class="d-flex flex-column flex-grow-1 pe-8">
									<!--begin::Stats-->
									<div class="d-flex flex-wrap">
										<label class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
										Clave de elector:</label>
										<label class="fw-bolder fs-6 text-gray-800">MORJN51111711H201</label>
									</div>
									<!--end::Stats-->
									<!--begin::Stats-->
									<div class="d-flex flex-wrap">
										<label class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="black"/>
													<rect x="6" y="12" width="7" height="2" rx="1" fill="black"/>
													<rect x="6" y="7" width="12" height="2" rx="1" fill="black"/>
												</svg>
											</span>
										Célular:</label>
										<label class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M8 8C8 7.4 8.4 7 9 7H16V3C16 2.4 15.6 2 15 2H3C2.4 2 2 2.4 2 3V13C2 13.6 2.4 14 3 14H5V16.1C5 16.8 5.79999 17.1 6.29999 16.6L8 14.9V8Z" fill="black"/>
													<path d="M22 8V18C22 18.6 21.6 19 21 19H19V21.1C19 21.8 18.2 22.1 17.7 21.6L15 18.9H9C8.4 18.9 8 18.5 8 17.9V7.90002C8 7.30002 8.4 6.90002 9 6.90002H21C21.6 7.00002 22 7.4 22 8ZM19 11C19 10.4 18.6 10 18 10H12C11.4 10 11 10.4 11 11C11 11.6 11.4 12 12 12H18C18.6 12 19 11.6 19 11ZM17 15C17 14.4 16.6 14 16 14H12C11.4 14 11 14.4 11 15C11 15.6 11.4 16 12 16H16C16.6 16 17 15.6 17 15Z" fill="black"/>
												</svg>
											</span>
										Teléfono:</label>
									</div>
									<!--end::Stats-->
									<!--begin::Stats-->
									<div class="d-flex flex-wrap">
										<a href="#" class="d-flex align-items-center text-gray-400 text-hover-primary mb-2">
											<!--begin::Svg Icon | path: icons/duotune/communication/com011.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19Z" fill="black" />
													<path d="M21 5H2.99999C2.69999 5 2.49999 5.10005 2.29999 5.30005L11.2 13.3C11.7 13.7 12.4 13.7 12.8 13.3L21.7 5.30005C21.5 5.10005 21.3 5 21 5Z" fill="black" />
												</svg>
											</span>
											<!--end::Svg Icon-->
										Correo electrónico</a>
									</div>
									<!--end::Stats-->
									<!--begin::Stats-->
									<div class="d-flex flex-wrap">
										<label class="d-flex align-items-center text-gray-400 text-hover-primary me-5 mb-2">
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2C17.5 2 22 6.5 22 12ZM12 7C10.3 7 9 8.3 9 10C9 11.7 10.3 13 12 13C13.7 13 15 11.7 15 10C15 8.3 13.7 7 12 7Z" fill="black"/>
													<path d="M12 22C14.6 22 17 21 18.7 19.4C17.9 16.9 15.2 15 12 15C8.8 15 6.09999 16.9 5.29999 19.4C6.99999 21 9.4 22 12 22Z" fill="black"/>
												</svg>
											</span>
										Meta personal</label>
										<!--end::Stats-->
										<!--begin::Stat-->
										<div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
											<!--begin::Number-->
											<div class="d-flex align-items-center">
												<!--begin::Svg Icon | path: icons/duotune/arrows/arr066.svg-->
												<span class="svg-icon svg-icon-3 svg-icon-success me-2">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
														<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
														<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
													</svg>
												</span>
												<!--end::Svg Icon-->
												<div class="fs-2 fw-bolder" data-kt-countup="true" data-kt-countup-value="10">0</div>
											</div>
											<!--end::Number-->
											<!--begin::Label-->
											<div class="fw-bold fs-6 text-gray-400">Meta</div>
											<!--end::Label-->
										</div>
										<!--end::Stat-->
										<!--begin::Stat-->
										<div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
											<!--begin::Number-->
											<div class="d-flex align-items-center">
												<!--begin::Svg Icon | path: icons/duotune/arrows/arr065.svg-->
												<span class="svg-icon svg-icon-3 svg-icon-success me-2">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
														<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
														<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
													</svg>
												</span>
												<!--end::Svg Icon-->
												<div class="fs-2 fw-bolder" data-kt-countup="true" data-kt-countup-value="10">0</div>
											</div>
											<!--end::Number-->
											<!--begin::Label-->
											<div class="fw-bold fs-6 text-gray-400">Avance</div>
											<!--end::Label-->
										</div>
										<!--end::Stat-->
										<!--begin::Stat-->
										<div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3">
											<!--begin::Number-->
											<div class="d-flex align-items-center">
												<!--begin::Svg Icon | path: icons/duotune/arrows/arr066.svg-->
												<span class="svg-icon svg-icon-3 svg-icon-success me-2">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
														<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
														<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
													</svg>
												</span>
												<!--end::Svg Icon-->
												<div class="fs-2 fw-bolder" data-kt-countup="true" data-kt-countup-value="60" data-kt-countup-prefix="%">0</div>
											</div>
											<!--end::Number-->
											<!--begin::Label-->
											<div class="fw-bold fs-6 text-gray-400">Progreso</div>
											<!--end::Label-->
										</div>
										<!--end::Stat-->
									</div>
									<!--end::Stats-->
								</div>
								<!--end::Wrapper-->					
							</div>
							<!--end::Stats-->
						</div>
						<!--end::Info-->
					</div>
					<!--end::Details-->
				</div>
				<!--begin::details View-->
			
				<!--begin::Card header-->
				<div class="card-header cursor-pointer bg-danger">
					<!--begin::Card title-->
					<div class="card-title m-0">
						<h3 class="fw-bolder m-0 text-white">METAS MUNICIPALES</h3>
					</div>
					<!--end::Card title-->
				</div>
				<!--begin::Row-->
				<div class="row g-0">
					<!--begin::Col-->
					<div class="col-3">
						<!--begin::Card-->
						<div class="card card-bordered bg-danger">
							
							
							<!--begin::Card body-->
							<div class="card-body">
								<!--begin::Row-->
								<div class="row row-cols-1 g-10 min-h-200px">
									<!--begin::Col-->
									<div class="col card-title">
										<!--begin::Card-->
										
										<h3 class="card-label text-white">PADRÓN</h3>
										
										<!--end::Card-->
									</div>
									<!--end::Col-->

									<!--begin::Col-->
									<div class="col draggable">
										<!--begin::Card-->
									
										<h3 class="card-label text-white">LISTA NOMINAL</h3>
											
							
										<!--end::Card-->
									</div>
									<!--end::Col-->

									<!--begin::Col-->
									<div class="col draggable">
										<!--begin::Card-->
										
										<h3 class="card-label text-white">PARTICIPACIÓN ESTIMADA </h3>
											
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
							</div>
							<!--end::Card body-->
						</div>
						<!--end::Card-->
					</div>
					<!--end::Col-->

					<!--begin::Col-->
					<div class="col-9">
						<!--begin::Card-->
						<div class="card card-bordered">


							<!--begin::Card body-->
							<div class="card-body">
								<!--begin::Row-->
								<div class="row row-cols-1 g-10 min-h-200px draggable-zone">
									<!--begin::Col-->
									<div class="col draggable">
										<!--begin::Card-->
										<div class="card">
										<h3 class="card-label">10,047</h3>
											
										</div>
										<!--end::Card-->
									</div>
									<!--end::Col-->

									<!--begin::Col-->
									<div class="col draggable">
										<!--begin::Card-->
										<div class="card">
										<h3 class="card-label">9,067</h3>
										</div>
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col draggable">
										<!--begin::Card-->
										<div class="card">
										<h3 class="card-label">54,440</h3>
										</div>
										<!--end::Card-->
									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
							</div>
							<!--end::Card body-->
						</div>
						<!--end::Card-->
					</div>
					<!--end::Col-->
				</div>
				<!--end::Row-->
				<div class="row g-0">
					<!--begin::Col-->
					<div class="col-3">
						<!--begin::Card-->
						<div class="card card-bordered bg-danger">
							<!--begin::Card body-->
							<div class="card-body">
								<!--begin::Row-->
								<div class="row row-cols-1 g-10 min-h-200px">
									
									<!--begin::Col-->
									<div class="col">
										<!--begin::Card-->
										
											
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
											META
										
										<!--end::Card-->
									</div>
									<!--end::Col-->

									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
											ZONE
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
										SECCIONES
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
										COORDINADORES DE SECCIÓN
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
										COORDINADORES DE CIRCULO
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
										ACTIVISTAS
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
										MIEMBROS DE CIRCULOS DE ACTIVISMO
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col text-white">
										<!--begin::Card-->
										
											LISTA ESTRUCTURADA
										
										<!--end::Card-->
									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
							</div>
							<!--end::Card body-->
						</div>
						<!--end::Card-->
					</div>
					<!--end::Col-->

					<!--begin::Col-->
					<div class="col-9">
						<!--begin::Card-->
										<!--begin::Tables Widget 13-->
										<div class="card mb-5 mb-xl-8">
											<!--begin::Body-->
											<div class="card-body py-3">
												<!--begin::Table container-->
												<div class="table-responsive">
													<!--begin::Table-->
													<table class="table table-row-bordered table-row-gray-100 align-middle gs-0 gy-3">
														<!--begin::Table head-->
														<thead>
															<tr class="fw-bolder text-muted">
															
																<th class="min-w-150px"></th>
																<th class="min-w-140px">Avance</th>
																<th class="min-w-120px">Progreso</th>
																<th class="min-w-120px">Vista detallada</th>
																<th class="min-w-120px">Descarga</th>
															</tr>
														</thead>
														<!--end::Table head-->
														<!--begin::Table body-->
														<tbody>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">3,254</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">3336</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">102.27%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de cargos</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">0</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de zonas</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">10</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">10</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de secciones</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">10</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">10</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de coordinadores seccionales</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">33</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">32</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">96.97%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de coordinadores de circulo</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">325</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">324</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">99.39%</a>
																	
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de activistas</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">3,254</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">3,338</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">102.27%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista de miembros</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">369</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">357</a>
																</td>
																<td>
																	<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">99.46%</a>
																</td>
																<td>
																	<span class="badge badge-light-danger">Lista estructurada</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
														</tbody>
														<!--end::Table body-->
													</table>
													<!--end::Table-->
												</div>
												<!--end::Table container-->
											</div>
											<!--begin::Body-->
										</div>
										<!--end::Tables Widget 13-->
						<!--end::Card-->
					</div>
					<!--end::Col-->
				</div>

					
						
					
				
			</div>
			<!--end::Navbar-->
			<!--begin::Modal - Create Api Key-->
			<div class="modal fade" id="kt_modal_create_api_key" tabindex="-1" aria-hidden="true">
				<!--begin::Modal dialog-->
				<div class="modal-dialog modal-dialog-centered mw-650px">
										<!--begin::Modal content-->
										<div class="modal-content">
											<!--begin::Modal header-->
											<div class="modal-header" id="kt_modal_create_api_key_header">
												<!--begin::Modal title-->
												<h2>Asignar prospectos</h2>
												<!--end::Modal title-->
												<!--begin::Close-->
												<div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
													<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
													<span class="svg-icon svg-icon-1">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
															<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
															<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
														</svg>
													</span>
													<!--end::Svg Icon-->
												</div>
												<!--end::Close-->
											</div>
											<!--end::Modal header-->
											<!--begin::Form-->
											<form id="kt_modal_create_api_key_form" class="form" action="#">
												<!--begin::Modal body-->
												<div class="modal-body py-10 px-lg-17">
													<!--begin::Scroll-->
													<div class="scroll-y me-n7 pe-7" id="kt_modal_create_api_key_scroll" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-max-height="auto" data-kt-scroll-dependencies="#kt_modal_create_api_key_header" data-kt-scroll-wrappers="#kt_modal_create_api_key_scroll" data-kt-scroll-offset="300px">
														<!--begin::Notice-->
														<div class=" mb-10 p-6">
															
															<!--begin::Wrapper-->
															<div class="d-flex flex-grow-1">
																<!--begin::Content-->
																<div class="fw-bold">
																	<h4 class="text-gray-900 fw-bolder">Patrocinador activista activista</h4>
																		<div class="fs-6 text-gray-700">Nombre: 
																			<label class="fs-5 fw-bold mb-2 text-danger">MARIA GUADALUPE AQUINO RODRIGUEZ</label>
																		</div>
																		<div class="fs-6 text-gray-700">AQRDGD82083114M600</div>
																</div>
																<!--end::Content-->
															</div>
															<!--end::Wrapper-->
														</div>
														<!--end::Notice-->
														<div class="mb-5 fv-row">
															<h2>Asignar prospectos</h2>
														</div>
														
														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
														    <input type="text" class="form-control" placeholder="Buscar por clave de elector" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
														    <input type="text" class="form-control" placeholder="Fecha de nacimiento formato AAAAMMDD" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
														    <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->	

														<!--begin::Input group-->
														<div class="mb-5 fv-row">
															<!--begin::Label-->
															<label class="required fs-5 fw-bold mb-2">Nombre</label>
															<!--end::Label-->
															<!--begin::Input-->
															<input type="text" class="form-control form-control-solid" name="name" />
															<!--end::Input-->
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="material-icons" style="font-size:20px">mail</i></span>
														    <input type="text" class="form-control" placeholder="Correo electrónico" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="material-icons" style="font-size:20px">phonelink_ring</i></i></span>
														    <input type="text" class="form-control" placeholder="Célular" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class="material-icons" style="font-size:20px">phone</i></span>
														    <input type="text" class="form-control" placeholder="Teléfono" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class='fab fa-twitter' style='font-size:20px'></i></span>
														    <input type="text" class="form-control" placeholder="Twitter" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->

														<!--begin::Input group-->
														<div class="input-group mb-5">
														    <span class="input-group-text" id="basic-addon1"><i class='fab fa-facebook-square' style='font-size:20px'></i></span>
														    <input type="text" class="form-control" placeholder="Facebook" aria-label="Username" aria-describedby="basic-addon1"/>
														</div>
														<!--end::Input group-->
														
														
														
														
														
													</div>
													<!--end::Scroll-->
												</div>
												<!--end::Modal body-->
												<!--begin::Modal footer-->
												<div class="modal-footer flex-center">
													<!--begin::Button-->
													<button type="reset" id="kt_modal_create_api_key_cancel" class="btn btn-light me-3">Discard</button>
													<!--end::Button-->
													<!--begin::Button-->
													<button type="submit" id="kt_modal_create_api_key_submit" class="btn btn-danger">
														<span class="indicator-label">Asignar</span>
														<span class="indicator-progress">Please wait...
														<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
													</button>
													<!--end::Button-->
												</div>
												<!--end::Modal footer-->
											</form>
											<!--end::Form-->
										</div>
										<!--end::Modal content-->
				</div>
				<!--end::Modal dialog-->
			</div>
			<!--end::Modal - Create Api Key-->
			<!--begin::Modal - Create App-->
			<div class="modal fade" id="kt_modal_create_app" tabindex="-1" aria-hidden="true">
			<!--begin::Modal dialog-->
			<div class="modal-dialog modal-dialog-centered mw-900px">
				<!--begin::Modal content-->
				<div class="modal-content">
					<!--begin::Modal header-->
					<div class="modal-header">
						<!--begin::Modal title-->
						<h2>Casilla 2330B</h2>
						<!--end::Modal title-->
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-color-danger" data-bs-dismiss="modal">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-1">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Modal header-->
					<!--begin::Modal body-->
					<div class="modal-body py-lg-10 px-lg-10">
						<!--begin::Stepper-->
						<div class="stepper stepper-pills stepper-column d-flex flex-column flex-xl-row flex-row-fluid" id="kt_modal_create_app_stepper">
							<!--begin::Aside-->
							<div class="d-flex justify-content-center justify-content-xl-start flex-row-auto w-100 w-xl-300px">
								<!--begin::Nav-->
								<div class="stepper-nav ps-lg-10">
									<!--begin::Step 1-->
									<div class="stepper-item current" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">1</span>
										</div>
										<!--end::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Detalles</h3>
											
										</div>
										<!--end::Label-->
									</div>
									<!--end::Step 1-->
									<!--begin::Step 2-->
									<div class="stepper-item" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">2</span>
										</div>
										<!--begin::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Reporte</h3>
											<div class="stepper-desc">Parte 1</div>
										</div>
										<!--begin::Label-->
									</div>
									<!--end::Step 2-->
									<!--begin::Step 3-->
									<div class="stepper-item" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">3</span>
										</div>
										<!--end::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Reporte</h3>
											<div class="stepper-desc">Parte 2</div>
										</div>
										<!--end::Label-->
									</div>
									<!--end::Step 3-->
									<!--begin::Step 4-->
									<div class="stepper-item" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">4</span>
										</div>
										<!--end::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Incidentes</h3>
											<div class="stepper-desc">Parte 1</div>
										</div>
										<!--end::Label-->
									</div>
									<!--end::Step 4-->

									<!--begin::Step 5-->
									<div class="stepper-item" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">5</span>
										</div>
										<!--end::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Incidentes</h3>
											<div class="stepper-desc">Parte 2</div>
										</div>
										<!--end::Label-->
									</div>
									<!--end::Step 5-->
									<!--begin::Step 6-->
									<div class="stepper-item" data-kt-stepper-element="nav">
										<!--begin::Line-->
										<div class="stepper-line w-40px"></div>
										<!--end::Line-->
										<!--begin::Icon-->
										<div class="stepper-icon w-40px h-40px">
											<i class="stepper-check fas fa-check"></i>
											<span class="stepper-number">6</span>
										</div>
										<!--end::Icon-->
										<!--begin::Label-->
										<div class="stepper-label">
											<h3 class="stepper-title">Completo</h3>
											<div class="stepper-desc">Revisa y Guarda</div>
										</div>
										<!--end::Label-->
									</div>
									<!--end::Step 6-->
								</div>
								<!--end::Nav-->
							</div>
							<!--begin::Aside-->
							<!--begin::Content-->
							<div class="flex-row-fluid py-lg-5 px-lg-15">
								<!--begin::Form-->
								<form class="form" novalidate="novalidate" id="kt_modal_create_app_form">
									<!--begin::Step 1-->
									<div class="current" data-kt-stepper-element="content">
										<div class="w-100">
												<div class="fs-6 text-dark-700">
												Ciudad: <label class="fs-5 fw-bold mb-2 text-danger">Tecoutitlán de Corona</label>
												</div>

												<div class="fs-6 text-dark-700">
													Sección: <label class="fs-5 fw-bold mb-2 text-danger">2330</label>
													Padrón: <label class="fs-5 fw-bold mb-2 text-danger">673</label>
													Lista nominal: <label class="fs-5 fw-bold mb-2 text-danger">623</label>		
												</div>

												<div class="fs-6 text-dark-700">
													Tipo: <label class="fs-5 fw-bold mb-2 text-danger">No urbana</label>
													Tipo de domicialio: <label class="fs-5 fw-bold mb-2 text-danger">E</label>
												</div>

												<div class="fs-6 text-dark-700">
													Domicilio: <label class="fs-5 fw-bold mb-2 text-danger">PORFIRÍO DÍAZ, #19, BARRIO EMILIO ZAPATA, TECOUTITLÁN DE CORONA, 49250</label>
												</div>

												<div class="fs-6 text-dark-700">
													REFERENCIA: <label class="fs-5 fw-bold mb-2 text-danger">ENTRE ABASOLO Y BUGAMBILIA</label>
												</div>
											
										</div>
									</div>
									<!--end::Step 1-->
									<!--begin::Step 2-->
									<div data-kt-stepper-element="content">
										<div class="w-100">
											<!--begin::Input group-->
											<div class="fv-row">
												<!--begin::Label-->
												<label class="d-flex align-items-center fs-5 fw-bold mb-4">
													<span class="required">Ingresa los datos</span>
												</label>
												<!--end::Label-->
												
												<!--begin::Label-->
												<label class="d-flex align-items-center fs-6 fw-bold mb-4">
													Presente:
												</label>
												<!--end::Label-->
												<div class="card-body pt-2 row">
												<div class="col-xl">
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-2">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">PRESIDENTE</a>
														</div>
														<!--end::Description-->
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-2	">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">SECRETARIA</a>
														</div>
														<!--end::Description-->
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-2">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">SECRETARIA 1</a>
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-2">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">SECRETARIA 2</a>
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
												</div>
												<div class="col-xl">
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-5">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">ESCRUTADOR 1</a>
															
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-5">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">ESCRUTADOR 2</a>
															
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-5">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">ESCRUTADOR 3</a>
															
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-5">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">PROPIETARIO 1</a>
															
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->
													<!--begin::Item-->
													<div class="d-flex align-items-center mb-8">
														
														<!--begin::Checkbox-->
														<div class="form-check form-check-custom form-check-solid mx-5">
															<input class="form-check-input" type="checkbox" value="" />
														</div>
														<!--end::Checkbox-->
														<!--begin::Description-->
														<div class="flex-grow-1">
															<a class="text-gray-800 fw-bolder fs-6">PROPIETARIO 2</a>
														
														</div>
														<!--end::Description-->
														
													</div>
													<!--end:Item-->

													
												</div>
												</div>
												
											</div>
											<!--end::Input group-->
										</div>
									</div>
									<!--end::Step 2-->
									<!--begin::Step 3-->
									<div data-kt-stepper-element="content">
										<div class="w-100">
											
											<!--begin::Input group-->
											<div class="fv-row">
												<!--begin::Content-->
												<div class="fw-bold">
													<!--begin::Input group-->
													<div class="input-group mb-5">
														<span class="input-group-text" id="basic-addon1"><i class="material-icons">add_alarm</i></span>
														<input type="text" class="form-control" placeholder="Hora de apertura" aria-label="Username" aria-describedby="basic-addon1"/>
													</div>
													<!--end::Input group-->
													<!--begin::Input group-->
													<div class="input-group mb-5">
														<span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
														<input type="text" class="form-control" placeholder="Presidente alterno" aria-label="Username" aria-describedby="basic-addon1"/>
													</div>
													<!--end::Input group-->	
													<!--begin::Input group-->
													<div class="input-group mb-5">
														<span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
														<input type="text" class="form-control" placeholder="Secretario alterno 1" aria-label="Username" aria-describedby="basic-addon1"/>
													</div>
													<!--end::Input group-->
													<!--begin::Input group-->
													<div class="input-group mb-5">
														<span class="input-group-text" id="basic-addon1"><i class="fas fa-pen"></i></span>
														<input type="text" class="form-control" placeholder="Secretario alterno 2" aria-label="Username" aria-describedby="basic-addon1"/>
													</div>
													<!--end::Input group-->
												</div>
												<!--end::Content-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">Detalles:</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
											</div>
											<!--end::Input group-->
										</div>
									</div>
									<!--end::Step 3-->
									<!--begin::Step 4-->
									<div data-kt-stepper-element="content">
										<div class="w-100">
											<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Hubo incidente en la instalación de la casilla?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Hubo incidentes durante el desarrollo de la votación?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Hubo incidentes al cierre de la votación?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Hubo incidentes escrutinio y cómputo?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
										</div>
										
									</div>
									<!--end::Step 4-->
									<!--begin::Step 5-->
									<div data-kt-stepper-element="content">
									<div class="w-100">
										<!--begin::Input group-->
										<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Se abrió la casilla en tiempo y forma?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Se cambio la casilla de domicilio, porque y a donde?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Estuvieron presentes los funcionarios publicados?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5 fv-row">
													<!--begin::Label-->
													<label class="fs-5 fw-bold mb-2">¿Estuvieron presentes los representantes de nuestro partido?</label>
													<!--end::Label-->
													<!--begin::Input-->
													<textarea class="form-control form-control-solid" rows="3" name="description" placeholder="Breve descripción"></textarea>
													<!--end::Input-->
												</div>
												<!--end::Input group-->
												</div>	
									</div>
									<!--end::Step 5-->
									<!--begin::Step 6-->
									<div data-kt-stepper-element="content">
										<div class="w-100 text-center">
											<!--begin::Heading-->
											<h1 class="fw-bolder text-dark mb-3">¡Exito!</h1>
											<!--end::Heading-->
											<!--begin::Description-->
											<div class="text-muted fw-bold fs-3">Se guardaron los datos ingresados</div>
											<!--end::Description-->
											<!--begin::Illustration-->
											<div class="text-center px-4 py-15">
												<img src="assets/media/illustrations/sketchy-1/9.png" alt="" class="mw-100 mh-300px" />
											</div>
											<!--end::Illustration-->
										</div>
									</div>
									<!--end::Step 6-->
									<!--begin::Actions-->
									<div class="d-flex flex-stack pt-10">
										<!--begin::Wrapper-->
										<div class="me-2">
											<button type="button" class="btn btn-lg btn-light-danger me-3" data-kt-stepper-action="previous">
											<!--begin::Svg Icon | path: icons/duotune/arrows/arr063.svg-->
											<span class="svg-icon svg-icon-3 me-1">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black" />
													<path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black" />
												</svg>
											</span>
											<!--end::Svg Icon-->Back</button>
										</div>
										<!--end::Wrapper-->
										<!--begin::Wrapper-->
										<div>
											<button type="button" class="btn btn-lg btn-danger" data-kt-stepper-action="submit">
												<span class="indicator-label">Submit
												<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
												<span class="svg-icon svg-icon-3 ms-2 me-0">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
														<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
														<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
													</svg>
												</span>
												<!--end::Svg Icon--></span>
												<span class="indicator-progress">Please wait...
												<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
											</button>
											<button type="button" class="btn btn-lg btn-danger" data-kt-stepper-action="next">Continue
											<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
											<span class="svg-icon svg-icon-3 ms-1 me-0">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
													<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
												</svg>
											</span>
											<!--end::Svg Icon--></button>
										</div>
										<!--end::Wrapper-->
									</div>
									<!--end::Actions-->
								</form>
								<!--end::Form-->
							</div>
							<!--end::Content-->
						</div>
						<!--end::Stepper-->
					</div>
					<!--end::Modal body-->
				</div>
				<!--end::Modal content-->
			</div>
			<!--end::Modal dialog-->
			</div>
			<!--end::Modal - Create App-->
		</div>
		<!--end::Container-->				
	</div>
	<!--end::Post-->

									

<?php
   include('footer.php');
?>