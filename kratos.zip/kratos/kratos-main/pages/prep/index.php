<?php 
    include('../../bar.php');
?>


	<!--begin::Toolbar-->
	<div class="toolbar" id="kt_toolbar">
		<!--begin::Container-->
		<div id="kt_toolbar_container" class="container-xxl d-flex flex-stack">
			<!--begin::Page title-->
			<div data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}" class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
				<!--begin::Title-->
				<a href="/KRATOS/dashboard.php">
					<h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1">PREP</h1>
				</a>
				<!--end::Title-->
				<!--begin::Separator-->
				<span class="h-20px border-gray-200 border-start mx-4"></span>
				<!--end::Separator-->
			</div>
			<!--end::Page title-->	
			<div class="d-flex align-items-center py-1">
				<!--begin::Wrapper-->
				<div class="me-4">
					<!--begin::Button-->
					<a href="#" class="btn btn-sm btn-light-danger" data-bs-toggle="modal" data-bs-target="#kt_modal_create_api_key" id="kt_toolbar_primary_button">MUNICIPIO</a>
					<!--end::Button-->
				</div>
				<!--end::Wrapper-->
				<!--begin::Wrapper-->
				<div class="me-4">
					<!--begin::Button-->
					<a href="#" class="btn btn-sm btn-light-danger" data-bs-toggle="modal" data-bs-target="#kt_modal_create_api_key" id="kt_toolbar_primary_button">DIPUTADOS LOCALES</a>
					<!--end::Button-->
				</div>
				<!--end::Wrapper-->
				<!--begin::Wrapper-->
				<div class="me-4">
					<!--begin::Button-->
					<a href="#" class="btn btn-sm btn-light-danger" data-bs-toggle="modal" data-bs-target="#kt_modal_create_api_key" id="kt_toolbar_primary_button">DIPUTADOS FEDERALES</a>
					<!--end::Button-->
				</div>
				<!--end::Wrapper-->
			</div>
			<!--end::Actions-->
		</div>
		<!--end::Container-->
	</div>
	<!--end::Toolbar-->	
</div>
<!--end::Content-->
<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Post-->
	<div class="post d-flex flex-column-fluid" id="kt_post">
		<!--begin::Container-->
		<div id="kt_content_container" class="container-xxl">
			<!--begin::Card header-->
			<div class="card-header cursor-pointer bg-danger">
				<!--begin::Card title-->
				<div class="card-title m-0">
					<h3 class="fw-bolder m-0 text-white">VISTA GENERAL</h3>
				</div>
				<!--end::Card title-->
			</div>
			<!--::Card header-->
			<!--begin::Tables Widget 13-->
			<div class="card">
				<!--begin::Body-->
				<div class="card-body py-3">
					<!--begin::Table container-->
					<div class="table-responsive">
						<!--begin::Table-->
						<table class="table table-row-bordered table-row-gray-100 align-middle gs-0 gy-3">
							<!--begin::Table body-->
							<tbody>
								<tr>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Localidad</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">Tecoutitlan de Corona</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">Lista Nominal</a>
									</td>
									<td>
										<span class="badge badge-light-danger">9,219</span>
									</td>
									<td class="text-end">
										<a href="" class="btn btn-icon btn-bg-light btn-active-color-danger	 btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-3">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
													<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
													<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
								</tr>
								<tr>
																
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Total de casillas</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">18</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">Total de votos</a>
									</td>
									<td>
										<span class="badge badge-light-danger">850</span>
									</td>
									<td class="text-end">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-3">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
													<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
													<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
								</tr>
								<tr>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Avance de casillas</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">Ganador</a>
									</td>
									<td>
										<span class="badge badge-light-danger">PRD</span>
									</td>
									<td class="text-end">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-3">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
													<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
													<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
								</tr>
							</tbody>
							<!--end::Table body-->
						</table>
						<!--end::Table-->
					</div>
					<!--end::Table container-->
				</div>
				<!--begin::Body-->
			</div>
			<!--end::Tables Widget 13-->
			<!--begin::Tables Widget 13-->
			<div class="card mb-5 mb-xl-8">
				<!--begin::Body-->
				<div class="card-body py-3">
					<!--begin::Table container-->
					<div class="table-responsive">
						<!--begin::Table-->
						<table class="table table-row-bordered table-row-gray-100 align-middle gs-0 gy-3">
							<!--begin::Table body-->
							<tbody>
								<tr>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Partidos politícos</a>
									</td>	
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PAN.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PRI.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PRD.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PV.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PT.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/MN.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/NA.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/Morena.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PHumanista.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PES.svg.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PANPRD.jpg" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PRIPV.png" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PANPRD.jpg" class="img-fluid" width="24" height="24">
									</td>
									<td>
										<img src="<?php print(ROOT_PATH) ?>assets/media/img/PRIPV.png" class="img-fluid" width="24" height="24">
									</td>
								</tr>
								<tr>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary fs-6">Votos por partido</a>
									</td>	
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">200</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">300</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">50</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
									<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
								</tr>
							</tbody>
							<!--end::Table body-->
						</table>
						<!--end::Table-->
					</div>
					<!--end::Table container-->
				</div>
				<!--begin::Body-->
			</div>
			<!--end::Tables Widget 13-->
			<!--begin::Card header-->
			<div class="card-header cursor-pointer bg-danger">
				<!--begin::Card title-->
				<div class="card-title m-0">
					<h3 class="fw-bolder m-0 text-white">REPORTE DE VOTACIÓN POR MAYOR </h3>
				</div>
				<!--end::Card title-->
			</div>
			<!--::Card header-->
			<!--begin::Tables Widget 13-->
			<div class="card mb-5 mb-xl-8">
				<!--begin::Body-->
				<div class="card-body py-3">
					<!--begin::Table container-->
					<div class="table-responsive">
						<!--begin::Table-->
						<table class="table table-row-bordered table-row-gray-100 align-middle gs-0 gy-2">
							<!--begin::Table head-->
							<thead>
								<tr class="fw-bolder text-dark">
									<th class="min-w-120px">INCIDENTE</th>
									<th class="min-w-120px">CASILLA</th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PAN.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PRI.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PRD.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PV.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PT.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/MN.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/NA.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/Morena.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PHumanista.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PES.svg.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PANPRD.jpg" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PRIPV.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PANPRD.jpg" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px"><img src="<?php print(ROOT_PATH) ?>assets/media/img/PRIPV.png" class="img-fluid" width="24" height="24"></th>
									<th class="min-w-120px">GANADOR</th>
									<th class="min-w-120px">TOTAL DE VOTOS</th>
								</tr>
							</thead>
							<!--end::Table head-->
							<!--begin::Table body-->
							<tbody>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2330B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">200</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">300</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">50</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">100</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger">PRD</span>
									</td>
									<td>
										<span class="badge badge-light-danger">850</span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2330C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2331C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2331B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2332E 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2332B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2333B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2333E 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2334C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2334B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2335B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2336B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2337B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2337C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2338C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2338B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2339C 1</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
								<tr>
									<td class="text-begin">
										<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
											<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
											<span class="svg-icon svg-icon-4 me-1">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M22 7H2V11H22V7Z" fill="black"/>
													<path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black"/>
												</svg>
											</span>
											<!--end::Svg Icon-->
										</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">2339B</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<a href="#" class="text-dark fw-bolder text-hover-primary d-block mb-1 fs-6">0</a>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
									<td>
										<span class="badge badge-light-danger"></span>
									</td>
								</tr>
							</tbody>
							<!--end::Table body-->
						</table>
						<!--end::Table-->
					</div>
					<!--end::Table container-->
				</div>
				<!--begin::Body-->
			</div>
		</div>
		<!--end::Container-->					
	</div>
	<!--end::Post-->
</div>	
<!--end::Content-->					
					
<?php
   include('../../footer.php');
?>