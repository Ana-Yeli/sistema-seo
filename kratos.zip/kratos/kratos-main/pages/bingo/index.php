<?php 
    include('../../bar.php');
?>
    
						<!--begin::Toolbar-->
						<div class="toolbar" id="kt_toolbar">
							<!--begin::Container-->
							<div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
								<!--begin::Page title-->
								<div data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}" class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
									<!--begin::Title-->
									<a href="/KRATOS/dashboard.php">
										<h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1">BINGO</h1>
									</a>
									<!--end::Title-->
									<!--begin::Separator-->
									<span class="h-20px border-gray-200 border-start mx-4"></span>
									<!--end::Separator-->
									
								</div>
								<!--end::Page title-->
								
								
							
							</div>
							<!--end::Container-->
						</div>
						<!--end::Toolbar-->
						
					</div>
					<!--end::Content-->

					<!--begin::Content-->
					<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
						<!--begin::Post-->
						<div class="post d-flex flex-column-fluid" id="kt_post">
							<!--begin::Container-->
							<div id="kt_content_container" class="container-xxl">
								<!--begin::Row-->
								<div class="row gy-5 g-xl-8">
									<!--begin::Col casilla-->
									<div class="col-xl-4">
										<!--begin::Mixed Widget 2-->
										<div class="card card-xl-stretch">
											<!--begin::Header-->
											<div class="card-header border-0 bg-white py-5">
											
												<div class="me-2">
													<a href="#" class="text-dark text-hover-primary fw-bolder fs-3">Buscar</a>
												</div>	
											</div>
											<!--end::Header-->
											<!--begin::Body-->
											<div class="card-body pt-2">
												<!--begin::Content-->
												<div class="fw-bold">

												<!--begin::Input group-->
												<div class="d-flex flex-column mb-5">
															
															<!--begin::Select-->
															<select name="category" data-control="select2" data-hide-search="true" data-placeholder="Selecciona un no. de sección" class="form-select form-select-solid">
																<option value="">Select a Category...</option>
																<option value="1">2330</option>
																<option value="2">2331</option>
																<option value="3">2332</option>
																<option value="4">2333</option>
																<option value="4">2334</option>
																<option value="4">2335</option>
																<option value="4">2336</option>
																<option value="4">2337</option>
																<option value="4">2338</option>
																<option value="4">2339</option>
															</select>
															<!--end::Select-->
														</div>
														<!--end::Input group-->

													<!--begin::Input group-->
													<div class="d-flex flex-column mb-5">
															
															<!--begin::Select-->
															<select name="category" data-control="select2" data-hide-search="true" data-placeholder="Selecciona una casilla" class="form-select form-select-solid">
																<option value="">Select a Category...</option>
																<option value="1">2330B</option>
																<option value="2">2330C 1</option>
																<option value="3">2331C 1</option>
																<option value="4">2331B</option>
																<option value="4">2332E 1</option>
																<option value="4">2332B</option>
																<option value="4">2333B</option>
																<option value="4">2333E 1</option>
																<option value="4">2334C 1</option>
																<option value="4">2334B</option>
																<option value="4">2335B</option>
																<option value="4">2336B</option>
																<option value="4">2337B</option>
																<option value="4">2337C 1</option>
																<option value="4">2338C 1</option>
																<option value="4">2338B</option>
																<option value="4">2339C 1</option>
															</select>
															<!--end::Select-->
														</div>
														<!--end::Input group-->

													<!--begin::Input group-->
													<div class="input-group mb-5">
														<span class="input-group-text" id="basic-addon1"><i class="material-icons">format_list_numbered</i></span>
														<input type="text" class="form-control" placeholder="No. de bingo" aria-label="Username" aria-describedby="basic-addon1"/>
													</div>
													<!--end::Input group-->
													<button type="button" class="form-control btn btn-lg btn-light-danger">Asignar voto</button>
																	
																
													
												</div>
												<!--end::Content-->
												
												
											</div>
											<!--end::Body-->
										</div>
										<!--end::Mixed Widget 2-->
									</div>
									<!--end::Col-->
									<!--begin::Col casilla-->
									<div class="col-xl-4">
										<!--begin::Mixed Widget 2-->
										<div class="card card-xl-stretch">
											<!--begin::Header-->
											<div class="card-header border-0 bg-white py-5">
												
												<div class="me-2">
															<a href="#" class="text-dark text-hover-primary fw-bolder fs-3">Información de la casilla</a>
														</div>			
											
											</div>
											<!--end::Header-->
											<!--begin::Body-->
											<div class="card-body pt-2 row">
												
											<!--begin::Wrapper-->
															<div class="d-flex flex-grow-1">
																<!--begin::Content-->
																<div class="fw-bold">
																	
																		<div class="fs-6 text-dark-700">
																			Municipio o Delegación:
																			<label class="fs-5 fw-bold mb-2 text-danger">Teocuitatlán de Corona</label>
																		</div>
																		<div class="fs-6 text-dark-700">
																			Sección: 
																			<label class="fs-5 fw-bold mb-2 text-danger">2330</label>
																		</div>
																		<div class="fs-6 text-dark-700">
																			Tipo de casilla: 
																			<label class="fs-5 fw-bold mb-2 text-danger">Básica</label>
																		</div>
																		<div class="fs-6 text-dark-700">
																			Domicilio: 
																			<label class="fs-5 fw-bold mb-2 text-danger">PROFÍRIO DÍAZ, #19, BARRIO EMILIANO ZAPATA, TEOCUITATLÁN DE CORONA, 29250</label>
																		</div>
																		<div class="fs-6 text-dark-700">
																			Ubicación: 
																			<label class="fs-5 fw-bold mb-2 text-danger">ESCUELA SECUNDARIA FEDERAL JOSÉ MARÍA DONATO</label>
																		</div>
																				
																</div>
																<!--end::Content-->
															</div>
															<!--end::Wrapper-->
												
											</div>
											<!--end::Body-->
										</div>
										<!--end::Mixed Widget 2-->
									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-4">
										<!--begin::Mixed Widget 7-->
										<div class="card card-xl-stretch-50 mb-5 mb-xl-8">
											<!--begin::Body-->
											<div class="card-body d-flex flex-column p-0">
												<!--begin::Stats-->
												<div class="flex-grow-1 card-p pb-0">
													<div class="d-flex flex-stack flex-wrap">
														<div class="me-2">
															<a href="#" class="text-dark text-hover-primary fw-bolder fs-3">Vista rapida</a>
														</div>
													</div>
												</div>
												<!--end::Stats-->
												<!--begin::Tables Widget 13-->
										<div class="card mb-5 mb-xl-8">
											<!--begin::Body-->
											<div class="card-body py-3">
												<!--begin::Table container-->
												<div class="table-responsive">
													<!--begin::Table-->
													<table class="table table-row-bordered table-row-gray-100 align-middle gs-0 gy-3">
														<!--begin::Table head-->
														<thead>
															<tr class="fw-bolder text-muted">
															
																<th class="min-w-140px"></th>
																<th class="min-w-140px">TOTAL</th>
																<th class="min-w-120px">VOTARON</th>
																<th class="min-w-120px">REPORTES</th>
															</tr>
														</thead>
														<!--end::Table head-->
														<!--begin::Table body-->
														<tbody>
															<tr>
																<td>
																	<span class="text-dark fw-bolder d-block mb-1 fs-6">Estructura:</span>
																</td>
																<td>
																	<span class="text-dark fw-bolder d-block mb-1 fs-6">271</span>
																</td>
																<td>
																	<span class="text-dark fw-bolder d-block mb-1 fs-6">188</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">Ciudadanos:</span>
																</td>
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">352</span>
																</td>
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">39</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															<tr>
																
																
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">Lista nominal:</span>
																</td>
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">623</span>
																</td>
																<td>
																<span class="text-dark fw-bolder d-block mb-1 fs-6">277</span>
																</td>
																<td class="text-end">
																	<a href="#" class="btn btn-icon btn-bg-light btn-active-color-danger btn-sm me-1">
																		<!--begin::Svg Icon | path: icons/duotune/general/gen019.svg-->
																		<span class="svg-icon svg-icon-3">
																			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
																				<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"/>
																				<path opacity="0.3" d="M13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H13Z" fill="black"/>
																				<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM13 14.4V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V14.4H8L11.3 17.7C11.7 18.1 12.3 18.1 12.7 17.7L16 14.4H13Z" fill="black"/>
																			</svg>
																		</span>
																		<!--end::Svg Icon-->
																	</a>
																</td>
															</tr>
															
														</tbody>
														<!--end::Table body-->
													</table>
													<!--end::Table-->
												</div>
												<!--end::Table container-->
											</div>
											<!--begin::Body-->
										</div>
										<!--end::Tables Widget 13-->
											</div>
											<!--end::Body-->
										</div>
										<!--end::Mixed Widget 7-->
										
									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
								
								
								<!--begin::Row-->
								<div class="g-5 g-xl-8">
									
									<!--begin::Col-->
									
										<!--begin::Tables Widget 5-->
										<div class="card card-xxl-stretch mb-5 mb-xl-8">
											<!--begin::Header-->
											<div class="card-header border-0 pt-5">
												<h3 class="card-title align-items-start flex-column">
													<span class="card-label fw-bolder fs-3 mb-1">Formato:</span>
													
												</h3>
												
											</div>
											<!--end::Header-->
											<!--begin::Body-->
											<div class="card-body py-3">
												<div class="tab-content">
													<!--begin::Tap pane-->
													<div class="tab-pane fade show active" id="kt_table_widget_5_tab_1">
														<!--begin::Table container-->
														<div class="table-responsive">
															<!--begin::Table-->
															<table class="table table-row-dashed table-row-gray-200 align-middle gs-0 gy-4">
																<!--begin::Table head-->
																<thead>
																	<tr class="border-0">
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																		<th class="p-0 min-w-50px"></th>
																	</tr>	
																</thead>
																<!--end::Table head-->
																<!--begin::Table body-->
																<tbody>

																	<tr class="border border-gray border-active active">
																		<td class="bg-warning text-center">1</td>
																		<td class="bg-warning text-center">2</td>
																		<td class="bg-white text-center">3</td>
																		<td class="bg-white text-center">4</td>
																		<td class="bg-primary text-center">5</td>
																		<td class="bg-white text-center">6</td>
																		<td class="bg-primary text-center">7</td>
																		<td class="bg-warning text-center">8</td>
																		<td class="bg-white text-center">9</td>
																		<td class="bg-primary text-center">10</td>
																		<td class="bg-primary text-center">11</td>
																		<td class="bg-white text-center">12</td>
																		<td class="bg-white text-center">13</td>
																		<td class="bg-white text-center">14</td>
																		<td class="bg-warning text-center">15</td>
																		<td class="bg-white text-center">16</td>
																		<td class="bg-primary text-center">17</td>
																		<td class="bg-white text-center">18</td>
																		<td class="bg-white text-center">19</td>
																		<td class="bg-success text-center">20</td>
																		<td class="bg-primary text-center">21</td>
																		<td class="bg-primary text-center">22</td>
																		<td class="bg-white text-center">23</td>
																		<td class="bg-white text-center">24</td>
																		<td class="bg-white text-center">25</td>
																	</tr>
																	
																	<tr class="border border-secondary border-active active">
																		<td class="bg-warning text-center">26</td>
																		<td class="bg-primary text-center">27</td>
																		<td class="bg-secondary text-center">28</td>
																		<td class="bg-primary text-center">29</td>
																		<td class="bg-primary text-center">30</td>
																		<td class="bg-secondary text-center">31</td>
																		<td class="bg-secondary text-center">32</td>
																		<td class="bg-secondary text-center">33</td>
																		<td class="bg-secondary text-center">34</td>
																		<td class="bg-primary text-center">35</td>
																		<td class="bg-secondary text-center">36</td>
																		<td class="bg-success text-center">37</td>
																		<td class="bg-warning text-center">38</td>
																		<td class="bg-primary text-center">39</td>
																		<td class="bg-secondary text-center">40</td>
																		<td class="bg-primary text-center">41</td>
																		<td class="bg-success text-center">42</td>
																		<td class="bg-primary text-center">43</td>
																		<td class="bg-primary text-center">44</td>
																		<td class="bg-primary text-center">45</td>
																		<td class="bg-primary text-center">46</td>
																		<td class="bg-secondary text-center">47</td>
																		<td class="bg-secondary text-center">48</td>
																		<td class="bg-secondary text-center">49</td>
																		<td class="bg-secondary text-center">50</td>
																	</tr>
																	
																	<tr class="border border-gray border-active active">
																		<td class="bg-white text-center">51</td>
																		<td class="bg-white text-center">52</td>
																		<td class="bg-white text-center">53</td>
																		<td class="bg-white text-center">54</td>
																		<td class="bg-white text-center">55</td>
																		<td class="bg-primary text-center">56</td>
																		<td class="bg-primary text-center">57</td>
																		<td class="bg-white text-center">58</td>
																		<td class="bg-white text-center">59</td>
																		<td class="bg-white text-center">60</td>
																		<td class="bg-white text-center">61</td>
																		<td class="bg-success text-center">62</td>
																		<td class="bg-white text-center">63</td>
																		<td class="bg-white text-center">64</td>
																		<td class="bg-success text-center">65</td>
																		<td class="bg-primary text-center">66</td>
																		<td class="bg-primary text-center">67</td>
																		<td class="bg-white text-center">68</td>
																		<td class="bg-white text-center">69</td>
																		<td class="bg-warning text-center">70</td>
																		<td class="bg-primary text-center">71</td>
																		<td class="bg-white text-center">72</td>
																		<td class="bg-white text-center">73</td>
																		<td class="bg-white text-center">74</td>
																		<td class="bg-white text-center">75</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-warning text-center">76</td>
																		<td class="bg-secondary text-center">77</td>
																		<td class="bg-primary text-center">78</td>
																		<td class="bg-primary text-center">79</td>
																		<td class="bg-secondary text-center">80</td>
																		<td class="bg-primary text-center">81</td>
																		<td class="bg-primary text-center">82</td>
																		<td class="bg-secondary text-center">83</td>
																		<td class="bg-primary text-center">84</td>
																		<td class="bg-primary text-center">85</td>
																		<td class="bg-primary text-center">86</td>
																		<td class="bg-primary text-center">87</td>
																		<td class="bg-warning text-center">88</td>
																		<td class="bg-secondary text-center">89</td>
																		<td class="bg-secondary text-center">90</td>
																		<td class="bg-secondary text-center">91</td>
																		<td class="bg-secondary text-center">92</td>
																		<td class="bg-success text-center">93</td>
																		<td class="bg-primary text-center">94</td>
																		<td class="bg-warning text-center">95</td>
																		<td class="bg-secondary text-center">96</td>
																		<td class="bg-warning text-center">97</td>
																		<td class="bg-primary text-center">98</td>
																		<td class="bg-secondary text-center">99</td>
																		<td class="bg-secondary text-center">100</td>
																	</tr>
																	
																	<tr class="border border-gray border-active active">
																		<td class="bg-white text-center">101</td>
																		<td class="bg-white text-center">102</td>
																		<td class="bg-primary text-center">103</td>
																		<td class="bg-white text-center">104</td>
																		<td class="bg-primary text-center">105</td>
																		<td class="bg-white text-center">106</td>
																		<td class="bg-warning text-center">107</td>
																		<td class="bg-white text-center">108</td>
																		<td class="bg-white text-center">109</td>
																		<td class="bg-white text-center">110</td>
																		<td class="bg-white text-center">111</td>
																		<td class="bg-white text-center">112</td>
																		<td class="bg-white text-center">113</td>
																		<td class="bg-white text-center">114</td>
																		<td class="bg-primary text-center">115</td>
																		<td class="bg-primary text-center">116</td>
																		<td class="bg-primary text-center">117</td>
																		<td class="bg-white text-center">118</td>
																		<td class="bg-primary text-center">119</td>
																		<td class="bg-primary text-center">120</td>
																		<td class="bg-primary text-center">121</td>
																		<td class="bg-primary text-center">122</td>
																		<td class="bg-white text-center">123</td>
																		<td class="bg-white text-center">124</td>
																		<td class="bg-white text-center">125</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-primary text-center">126</td>
																		<td class="bg-primary text-center">127</td>
																		<td class="bg-primary text-center">128</td>
																		<td class="bg-primary text-center">129</td>
																		<td class="bg-secondary text-center">130</td>
																		<td class="bg-secondary text-center">131</td>
																		<td class="bg-primary text-center">132</td>
																		<td class="bg-success text-center">133</td>
																		<td class="bg-secondary text-center">134</td>
																		<td class="bg-primary text-center">135</td>
																		<td class="bg-secondary text-center">136</td>
																		<td class="bg-warning text-center">137</td>
																		<td class="bg-secondary text-center">138</td>
																		<td class="bg-secondary text-center">139</td>
																		<td class="bg-secondary text-center">140</td>
																		<td class="bg-primary text-center">141</td>
																		<td class="bg-primary text-center">142</td>
																		<td class="bg-primary text-center">143</td>
																		<td class="bg-warning text-center">144</td>
																		<td class="bg-secondary text-center">145</td>
																		<td class="bg-secondary text-center">146</td>
																		<td class="bg-secondary text-center">147</td>
																		<td class="bg-warning text-center">148</td>
																		<td class="bg-secondary text-center">149</td>
																		<td class="bg-secondary text-center">150</td>
																	</tr>
																
																	<tr class="border border-gray border-active active">
																		<td class="bg-primary text-center">151</td>
																		<td class="bg-white text-center">152</td>
																		<td class="bg-white text-center">153</td>
																		<td class="bg-white text-center">154</td>
																		<td class="bg-primary text-center">55</td>
																		<td class="bg-white text-center">156</td>
																		<td class="bg-white text-center">157</td>
																		<td class="bg-white text-center">158</td>
																		<td class="bg-white text-center">159</td>
																		<td class="bg-white text-center">160</td>
																		<td class="bg-primary text-center">161</td>
																		<td class="bg-white text-center">162</td>
																		<td class="bg-white text-center">163</td>
																		<td class="bg-white text-center">164</td>
																		<td class="bg-white text-center">165</td>
																		<td class="bg-white text-center">166</td>
																		<td class="bg-white text-center">167</td>
																		<td class="bg-white text-center">168</td>
																		<td class="bg-white text-center">169</td>
																		<td class="bg-primary text-center">170</td>
																		<td class="bg-primary text-center">171</td>
																		<td class="bg-primary text-center">172</td>
																		<td class="bg-primary text-center">173</td>
																		<td class="bg-white text-center">174</td>
																		<td class="bg-white text-center">175</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-secondary text-center">176</td>
																		<td class="bg-primary text-center">177</td>
																		<td class="bg-primary text-center">178</td>
																		<td class="bg-secondary text-center">179</td>
																		<td class="bg-primary text-center">180</td>
																		<td class="bg-secondary text-center">181</td>
																		<td class="bg-secondary text-center">182</td>
																		<td class="bg-secondary text-center">183</td>
																		<td class="bg-secondary text-center">184</td>
																		<td class="bg-secondary text-center">185</td>
																		<td class="bg-primary text-center">186</td>
																		<td class="bg-success text-center">187</td>
																		<td class="bg-primary text-center">188</td>
																		<td class="bg-primary text-center">189</td>
																		<td class="bg-primary text-center">190</td>
																		<td class="bg-success text-center">191</td>
																		<td class="bg-primary text-center">192</td>
																		<td class="bg-secondary text-center">193</td>
																		<td class="bg-primary text-center">194</td>
																		<td class="bg-primary text-center">195</td>
																		<td class="bg-secondary text-center">196</td>
																		<td class="bg-secondary text-center">197</td>
																		<td class="bg-secondary text-center">198</td>
																		<td class="bg-secondary text-center">199</td>
																		<td class="bg-secondary text-center">200</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-white text-center">201</td>
																		<td class="bg-white text-center">202</td>
																		<td class="bg-white text-center">203</td>
																		<td class="bg-white text-center">204</td>
																		<td class="bg-white text-center">205</td>
																		<td class="bg-white text-center">206</td>
																		<td class="bg-white text-center">207</td>
																		<td class="bg-white text-center">208</td>
																		<td class="bg-white text-center">209</td>
																		<td class="bg-white text-center">210</td>
																		<td class="bg-primary text-center">211</td>
																		<td class="bg-primary text-center">212</td>
																		<td class="bg-white text-center">213</td>
																		<td class="bg-primary text-center">214</td>
																		<td class="bg-white text-center">215</td>
																		<td class="bg-primary text-center">216</td>
																		<td class="bg-white text-center">217</td>
																		<td class="bg-white text-center">218</td>
																		<td class="bg-primary text-center">219</td>
																		<td class="bg-white text-center">220</td>
																		<td class="bg-white text-center">221</td>
																		<td class="bg-white text-center">222</td>
																		<td class="bg-white text-center">223</td>
																		<td class="bg-white text-center">224</td>
																		<td class="bg-white text-center">225</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-primary text-center">226</td>
																		<td class="bg-success text-center">227</td>
																		<td class="bg-primary text-center">228</td>
																		<td class="bg-primary text-center">229</td>
																		<td class="bg-primary text-center">230</td>
																		<td class="bg-primary text-center">231</td>
																		<td class="bg-primary text-center">232</td>
																		<td class="bg-secondary text-center">233</td>
																		<td class="bg-primary text-center">234</td>
																		<td class="bg-primary text-center">235</td>
																		<td class="bg-secondary text-center">236</td>
																		<td class="bg-secondary text-center">237</td>
																		<td class="bg-secondary text-center">238</td>
																		<td class="bg-secondary text-center">239</td>
																		<td class="bg-primary text-center">240</td>
																		<td class="bg-secondary text-center">241</td>
																		<td class="bg-secondary text-center">242</td>
																		<td class="bg-secondary text-center">243</td>
																		<td class="bg-secondary text-center">244</td>
																		<td class="bg-secondary text-center">245</td>
																		<td class="bg-secondary text-center">246</td>
																		<td class="bg-secondary text-center">247</td>
																		<td class="bg-secondary text-center">248</td>
																		<td class="bg-secondary text-center">249</td>
																		<td class="bg-secondary text-center">250</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-primary text-center">251</td>
																		<td class="bg-white text-center">252</td>
																		<td class="bg-white text-center">253</td>
																		<td class="bg-white text-center">254</td>
																		<td class="bg-primary text-center">255</td>
																		<td class="bg-white text-center">256</td>
																		<td class="bg-white text-center">257</td>
																		<td class="bg-primary text-center">258</td>
																		<td class="bg-white text-center">259</td>
																		<td class="bg-warning text-center">260</td>
																		<td class="bg-white text-center">261</td>
																		<td class="bg-white text-center">262</td>
																		<td class="bg-white text-center">263</td>
																		<td class="bg-success text-center">264</td>
																		<td class="bg-white text-center">265</td>
																		<td class="bg-success text-center">266</td>
																		<td class="bg-white text-center">267</td>
																		<td class="bg-white text-center">268</td>
																		<td class="bg-white text-center">269</td>
																		<td class="bg-white text-center">270</td>
																		<td class="bg-white text-center">271</td>
																		<td class="bg-white text-center">272</td>
																		<td class="bg-white text-center">273</td>
																		<td class="bg-white text-center">274</td>
																		<td class="bg-white text-center">275</td>
																	</tr>
																	
																	<tr class="border border-secondary border-active active">
																		<td class="bg-primary text-center">276</td>
																		<td class="bg-secondary text-center">277</td>
																		<td class="bg-primary text-center">278</td>
																		<td class="bg-primary text-center">279</td>
																		<td class="bg-success text-center">280</td>
																		<td class="bg-success text-center">281</td>
																		<td class="bg-secondary text-center">282</td>
																		<td class="bg-primary text-center">283</td>
																		<td class="bg-primary text-center">284</td>
																		<td class="bg-secondary text-center">285</td>
																		<td class="bg-primary text-center">286</td>
																		<td class="bg-primary text-center">287</td>
																		<td class="bg-secondary text-center">288</td>
																		<td class="bg-secondary text-center">289</td>
																		<td class="bg-success text-center">290</td>
																		<td class="bg-secondary text-center">291</td>
																		<td class="bg-secondary text-center">292</td>
																		<td class="bg-secondary text-center">293</td>
																		<td class="bg-secondary text-center">294</td>
																		<td class="bg-secondary text-center">295</td>
																		<td class="bg-secondary text-center">296</td>
																		<td class="bg-secondary text-center">297</td>
																		<td class="bg-secondary text-center">298</td>
																		<td class="bg-secondary text-center">299</td>
																		<td class="bg-secondary text-center">300</td>
																	</tr>
																	
																	<tr class="border border-gray border-active active">
																		<td class="bg-primary text-center">301</td>
																		<td class="bg-white text-center">302</td>
																		<td class="bg-primary text-center">303</td>
																		<td class="bg-white text-center">304</td>
																		<td class="bg-white text-center">305</td>
																		<td class="bg-warning text-center">306</td>
																		<td class="bg-primary text-center">307</td>
																		<td class="bg-primary text-center">308</td>
																		<td class="bg-white text-center">309</td>
																		<td class="bg-primary text-center">310</td>
																		<td class="bg-white text-center">311</td>
																		<td class="bg-primary text-center">312</td>
																		<td class="bg-white text-center">313</td>
																		<td class="bg-primary text-center">314</td>
																		<td class="bg-primary text-center">315</td>
																		<td class="bg-primary text-center">316</td>
																		<td class="bg-white text-center">317</td>
																		<td class="bg-primary text-center">318</td>
																		<td class="bg-white text-center">319</td>
																		<td class="bg-white text-center">320</td>
																		<td class="bg-white text-center">321</td>
																		<td class="bg-white text-center">322</td>
																		<td class="bg-white text-center">323</td>
																		<td class="bg-white text-center">324</td>
																		<td class="bg-white text-center">325</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-secondary text-center">326</td>
																		<td class="bg-secondary text-center">327</td>
																		<td class="bg-primary text-center">328</td>
																		<td class="bg-primary text-center">329</td>
																		<td class="bg-primary text-center">330</td>
																		<td class="bg-primary text-center">331</td>
																		<td class="bg-primary text-center">332</td>
																		<td class="bg-warning text-center">333</td>
																		<td class="bg-secondary text-center">334</td>
																		<td class="bg-secondary text-center">335</td>
																		<td class="bg-primary text-center">336</td>
																		<td class="bg-primary text-center">337</td>
																		<td class="bg-primary text-center">338</td>
																		<td class="bg-secondary text-center">339</td>
																		<td class="bg-secondary text-center">340</td>
																		<td class="bg-primary text-center">341</td>
																		<td class="bg-primary text-center">342</td>
																		<td class="bg-secondary text-center">343</td>
																		<td class="bg-secondary text-center">344</td>
																		<td class="bg-secondary text-center">345</td>
																		<td class="bg-secondary text-center">346</td>
																		<td class="bg-secondary text-center">347</td>
																		<td class="bg-secondary text-center">348</td>
																		<td class="bg-secondary text-center">349</td>
																		<td class="bg-secondary text-center">350</td>
																	</tr>
																	
																	<tr class="border border-gray border-active active">
																		<td class="bg-warning text-center">351</td>
																		<td class="bg-white text-center">352</td>
																		<td class="bg-primary text-center">353</td>
																		<td class="bg-white text-center">354</td>
																		<td class="bg-primary text-center">355</td>
																		<td class="bg-white text-center">356</td>
																		<td class="bg-white text-center">357</td>
																		<td class="bg-white text-center">358</td>
																		<td class="bg-white text-center">359</td>
																		<td class="bg-white text-center">360</td>
																		<td class="bg-white text-center">361</td>
																		<td class="bg-white text-center">362</td>
																		<td class="bg-white text-center">363</td>
																		<td class="bg-white text-center">364</td>
																		<td class="bg-white text-center">365</td>
																		<td class="bg-white text-center">366</td>
																		<td class="bg-white text-center">367</td>
																		<td class="bg-white text-center">368</td>
																		<td class="bg-white text-center">369</td>
																		<td class="bg-white text-center">370</td>
																		<td class="bg-white text-center">371</td>
																		<td class="bg-white text-center">372</td>
																		<td class="bg-white text-center">373</td>
																		<td class="bg-white text-center">374</td>
																		<td class="bg-white text-center">375</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-secondary text-center">376</td>
																		<td class="bg-primary text-center">377</td>
																		<td class="bg-primary text-center">378</td>
																		<td class="bg-primary text-center">379</td>
																		<td class="bg-secondary text-center">380</td>
																		<td class="bg-warning text-center">381</td>
																		<td class="bg-secondary text-center">382</td>
																		<td class="bg-success text-center">383</td>
																		<td class="bg-primary text-center">384</td>
																		<td class="bg-secondary text-center">385</td>
																		<td class="bg-primary text-center">386</td>
																		<td class="bg-warning text-center">387</td>
																		<td class="bg-secondary text-center">388</td>
																		<td class="bg-secondary text-center">389</td>
																		<td class="bg-secondary text-center">390</td>
																		<td class="bg-secondary text-center">391</td>
																		<td class="bg-secondary text-center">392</td>
																		<td class="bg-warning text-center">393</td>
																		<td class="bg-secondary text-center">394</td>
																		<td class="bg-secondary text-center">395</td>
																		<td class="bg-secondary text-center">396</td>
																		<td class="bg-secondary text-center">397</td>
																		<td class="bg-secondary text-center">398</td>
																		<td class="bg-secondary text-center">399</td>
																		<td class="bg-secondary text-center">400</td>
																	</tr>
																
																	<tr class="border border-gray border-active active">
																		<td class="bg-white text-center">401</td>
																		<td class="bg-white text-center">402</td>
																		<td class="bg-white text-center">403</td>
																		<td class="bg-primary text-center">404</td>
																		<td class="bg-white text-center">405</td>
																		<td class="bg-primary text-center">406</td>
																		<td class="bg-white text-center">407</td>
																		<td class="bg-primary text-center">408</td>
																		<td class="bg-white text-center">409</td>
																		<td class="bg-primary text-center">410</td>
																		<td class="bg-primary text-center">411</td>
																		<td class="bg-white text-center">412</td>
																		<td class="bg-white text-center">413</td>
																		<td class="bg-white text-center">414</td>
																		<td class="bg-white text-center">415</td>
																		<td class="bg-white text-center">416</td>
																		<td class="bg-white text-center">417</td>
																		<td class="bg-primary text-center">418</td>
																		<td class="bg-primary text-center">419</td>
																		<td class="bg-white text-center">420</td>
																		<td class="bg-white text-center">421</td>
																		<td class="bg-white text-center">422</td>
																		<td class="bg-white text-center">423</td>
																		<td class="bg-white text-center">424</td>
																		<td class="bg-white text-center">425</td>
																	</tr>

																	<tr class="border border-gray border-active active">
																		<td class="bg-secondary text-center">426</td>
																		<td class="bg-success text-center">427</td>
																		<td class="bg-warning text-center">428</td>
																		<td class="bg-secondary text-center">429</td>
																		<td class="bg-primary text-center">430</td>
																		<td class="bg-success text-center">431</td>
																		<td class="bg-primary text-center">432</td>
																		<td class="bg-primary text-center">433</td>
																		<td class="bg-secondary text-center">434</td>
																		<td class="bg-warning text-center">435</td>
																		<td class="bg-secondary text-center">436</td>
																		<td class="bg-secondary text-center">437</td>
																		<td class="bg-success text-center">438</td>
																		<td class="bg-primary text-center">439</td>
																		<td class="bg-primary text-center">440</td>
																		<td class="bg-secondary text-center">441</td>
																		<td class="bg-warning text-center">442</td>
																		<td class="bg-primary text-center">443</td>
																		<td class="bg-secondary text-center">444</td>
																		<td class="bg-secondary text-center">445</td>
																		<td class="bg-secondary text-center">446</td>
																		<td class="bg-secondary text-center">447</td>
																		<td class="bg-secondary text-center">448</td>
																		<td class="bg-secondary text-center">449</td>
																		<td class="bg-secondary text-center">450</td>
																	</tr>

																</tbody>
																<!--end::Table body-->
															</table>
														</div>
														<!--end::Table-->
													</div>
													<!--end::Tap pane-->
													<!--begin::Tap pane-->
													<div class="tab-pane fade" id="kt_table_widget_5_tab_2">
														<!--begin::Table container-->
														<div class="table-responsive">
															<!--begin::Table-->
															<table class="table table-row-dashed table-row-gray-200 align-middle gs-0 gy-4">
																<!--begin::Table head-->
																<thead>
																	<tr class="border-0">
																		<th class="p-0 w-50px"></th>
																		<th class="p-0 min-w-150px"></th>
																		<th class="p-0 min-w-140px"></th>
																		<th class="p-0 min-w-110px"></th>
																		<th class="p-0 min-w-50px"></th>
																	</tr>
																</thead>
																<!--end::Table head-->
																<!--begin::Table body-->
																<tbody>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/plurk.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Brad Simmons</a>
																			<span class="text-muted fw-bold d-block">Movie Creator</span>
																		</td>
																		<td class="text-end text-muted fw-bold">React, HTML</td>
																		<td class="text-end">
																			<span class="badge badge-light-success">Approved</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/telegram.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Popular Authors</a>
																			<span class="text-muted fw-bold d-block">Most Successful</span>
																		</td>
																		<td class="text-end text-muted fw-bold">Python, MySQL</td>
																		<td class="text-end">
																			<span class="badge badge-light-warning">In Progress</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/bebo.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Active Customers</a>
																			<span class="text-muted fw-bold d-block">Movie Creator</span>
																		</td>
																		<td class="text-end text-muted fw-bold">AngularJS, C#</td>
																		<td class="text-end">
																			<span class="badge badge-light-danger">Rejected</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																</tbody>
																<!--end::Table body-->
															</table>
														</div>
														<!--end::Table-->
													</div>
													<!--end::Tap pane-->
													<!--begin::Tap pane-->
													<div class="tab-pane fade" id="kt_table_widget_5_tab_3">
														<!--begin::Table container-->
														<div class="table-responsive">
															<!--begin::Table-->
															<table class="table table-row-dashed table-row-gray-200 align-middle gs-0 gy-4">
																<!--begin::Table head-->
																<thead>
																	<tr class="border-0">
																		<th class="p-0 w-50px"></th>
																		<th class="p-0 min-w-150px"></th>
																		<th class="p-0 min-w-140px"></th>
																		<th class="p-0 min-w-110px"></th>
																		<th class="p-0 min-w-50px"></th>
																	</tr>
																</thead>
																<!--end::Table head-->
																<!--begin::Table body-->
																<tbody>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/kickstarter.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Bestseller Theme</a>
																			<span class="text-muted fw-bold d-block">Best Customers</span>
																		</td>
																		<td class="text-end text-muted fw-bold">ReactJS, Ruby</td>
																		<td class="text-end">
																			<span class="badge badge-light-warning">In Progress</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/bebo.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Active Customers</a>
																			<span class="text-muted fw-bold d-block">Movie Creator</span>
																		</td>
																		<td class="text-end text-muted fw-bold">AngularJS, C#</td>
																		<td class="text-end">
																			<span class="badge badge-light-danger">Rejected</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/vimeo.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">New Users</a>
																			<span class="text-muted fw-bold d-block">Awesome Users</span>
																		</td>
																		<td class="text-end text-muted fw-bold">Laravel,Metronic</td>
																		<td class="text-end">
																			<span class="badge badge-light-primary">Success</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																	<tr>
																		<td>
																			<div class="symbol symbol-45px me-2">
																				<span class="symbol-label">
																					<img src="assets/media/svg/brand-logos/telegram.svg" class="h-50 align-self-center" alt="" />
																				</span>
																			</div>
																		</td>
																		<td>
																			<a href="#" class="text-dark fw-bolder text-hover-primary mb-1 fs-6">Popular Authors</a>
																			<span class="text-muted fw-bold d-block">Most Successful</span>
																		</td>
																		<td class="text-end text-muted fw-bold">Python, MySQL</td>
																		<td class="text-end">
																			<span class="badge badge-light-warning">In Progress</span>
																		</td>
																		<td class="text-end">
																			<a href="#" class="btn btn-sm btn-icon btn-bg-light btn-active-color-primary">
																				<!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
																				<span class="svg-icon svg-icon-2">
																					<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																						<rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black" />
																						<path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black" />
																					</svg>
																				</span>
																				<!--end::Svg Icon-->
																			</a>
																		</td>
																	</tr>
																</tbody>
																<!--end::Table body-->
															</table>
														</div>
														<!--end::Table-->
													</div>
													<!--end::Tap pane-->
												</div>
											</div>
											<!--end::Body-->
										</div>
										<!--end::Tables Widget 5-->
									
									<!--end::Col-->
								</div>
								<!--end::Row-->
								
								
							</div>
							<!--end::Container-->
						</div>
						<!--end::Post-->
					</div>	



<?php
   include('../../footer.php');
?>

